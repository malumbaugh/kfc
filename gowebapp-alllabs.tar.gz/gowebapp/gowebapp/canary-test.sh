NODEPORT=$(kubectl get -o jsonpath="{.spec.ports[0].nodePort}" service gowebapp)
for i in {1..10}; do curl -s localhost:$NODEPORT | grep 'Tanzu\|"title"'; done
